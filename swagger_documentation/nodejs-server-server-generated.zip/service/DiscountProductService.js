'use strict';


/**
 * Check if the product have any discount available
 *
 * body Check_discount_req product object that needs to be checked against the store
 * returns Object
 **/
exports.api1Check_discountPOST = function(body) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


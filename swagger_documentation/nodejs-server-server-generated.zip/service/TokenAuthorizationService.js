'use strict';


/**
 * get jwt token from the system to use other secured routes
 * Multiple status values can be provided with comma separated strings
 *
 * returns Object
 **/
exports.api1Get_tokenGET = function() {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "bytes": [],
  "empty": true
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


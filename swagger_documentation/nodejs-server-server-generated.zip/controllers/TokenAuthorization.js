'use strict';

var utils = require('../utils/writer.js');
var TokenAuthorization = require('../service/TokenAuthorizationService');

module.exports.api1Get_tokenGET = function api1Get_tokenGET (req, res, next) {
  TokenAuthorization.api1Get_tokenGET()
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

'use strict';

var utils = require('../utils/writer.js');
var DiscountProduct = require('../service/DiscountProductService');

module.exports.api1Check_discountPOST = function api1Check_discountPOST (req, res, next) {
  var body = req.swagger.params['body'].value;
  DiscountProduct.api1Check_discountPOST(body)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

# SwaggerDiscountProject.Token

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**accessToken** | **String** |  | [optional] 
**refreshToken** | **String** |  | [optional] 



# SwaggerDiscountProject.DiscountProductApi

All URIs are relative to *https://virtserver.swaggerhub.com/t16643/discount/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api1CheckDiscountPost**](DiscountProductApi.md#api1CheckDiscountPost) | **POST** /api/1/check_discount | Check if the product have any discount available


<a name="api1CheckDiscountPost"></a>
# **api1CheckDiscountPost**
> Object api1CheckDiscountPost(body)

Check if the product have any discount available

### Example
```javascript
var SwaggerDiscountProject = require('swagger_discount_project');
var defaultClient = SwaggerDiscountProject.ApiClient.instance;

// Configure OAuth2 access token for authorization: petstore_auth
var petstore_auth = defaultClient.authentications['petstore_auth'];
petstore_auth.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new SwaggerDiscountProject.DiscountProductApi();

var body = new SwaggerDiscountProject.CheckDiscountReq(); // CheckDiscountReq | product object that needs to be checked against the store


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.api1CheckDiscountPost(body, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**CheckDiscountReq**](CheckDiscountReq.md)| product object that needs to be checked against the store | 

### Return type

**Object**

### Authorization

[petstore_auth](../README.md#petstore_auth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json


# SwaggerDiscountProject.CheckDiscountReq

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**productCode** | **String** |  | [optional] 
**userId** | **Number** |  | [optional] 
**amount** | **Number** |  | [optional] 



# SwaggerDiscountProject.CheckDiscountRes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**discountAmount** | **Number** |  | [optional] 



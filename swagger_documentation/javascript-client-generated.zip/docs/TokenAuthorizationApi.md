# SwaggerDiscountProject.TokenAuthorizationApi

All URIs are relative to *https://virtserver.swaggerhub.com/t16643/discount/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**api1GetTokenGet**](TokenAuthorizationApi.md#api1GetTokenGet) | **GET** /api/1/get_token | get jwt token from the system to use other secured routes


<a name="api1GetTokenGet"></a>
# **api1GetTokenGet**
> Object api1GetTokenGet()

get jwt token from the system to use other secured routes

Multiple status values can be provided with comma separated strings

### Example
```javascript
var SwaggerDiscountProject = require('swagger_discount_project');
var defaultClient = SwaggerDiscountProject.ApiClient.instance;

// Configure OAuth2 access token for authorization: petstore_auth
var petstore_auth = defaultClient.authentications['petstore_auth'];
petstore_auth.accessToken = 'YOUR ACCESS TOKEN';

var apiInstance = new SwaggerDiscountProject.TokenAuthorizationApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.api1GetTokenGet(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

**Object**

### Authorization

[petstore_auth](../README.md#petstore_auth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

